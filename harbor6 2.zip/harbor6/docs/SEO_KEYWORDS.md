# Keyword research: 100 search phrases

These phrases are **planning input**, not text to paste into pages. They decide category names, page titles, meta descriptions and the plain-language copy on category pages. Nothing here justifies adding a server that does not exist, and nothing guarantees a ranking. Check demand yourself in Google Search Console (Performance report) after the site has been live for a few weeks.

How they map to the site today: **server pages** (`/s/<id>/`) target "<name> discord server"; **category pages** (`/c/<category>/`) target the category phrases; the **home page** targets the broad discovery phrases. Groups marked *(needs data)* have no honest listings yet, so no page should be created for them until real servers exist.

## 1. Discord server discovery (10)
discord server search, find discord servers, discord server finder, discord server directory, discord server list, search discord communities, how to find discord servers, discord server discovery, join discord servers, discord communities to join

## 2. Gaming communities (10) *(4 listings today)*
gaming discord servers, official game discord servers, valorant discord server, fortnite discord server, official fortnite discord, fps gaming discord, esports discord servers, looking for group discord, game news discord server, discord servers for gamers

## 3. Minecraft servers (10) *(2 listings today)*
minecraft discord server, official minecraft discord, hypixel discord, minecraft community discord, minecraft skyblock discord, minecraft minigames discord, minecraft survival discord, minecraft modding discord *(needs data)*, minecraft server network discord, best minecraft discord servers

## 4. Anime communities (10) *(needs data)*
anime discord servers, anime discussion discord, manga discord server, anime watch party discord, seasonal anime discord, anime recommendations discord, anime art discord, japanese culture discord, cosplay discord server, otaku discord community

## 5. Technology communities (10)
tech discord servers, official tech support discord, smartphone discord server, pc building discord, linus tech tips discord, retro computing discord, amiga community discord, mechanical keyboard discord, custom keyboard firmware discord, gadget reviews discord

## 6. Programming and web development (10)
programming discord servers, python discord server, rust discord server, typescript discord, web development discord, javascript framework discord, laravel discord, tailwind css discord, svelte discord, developer communities discord

## 7. Education and learning (10)
study discord servers, learn programming discord, competitive programming discord, cs50 discord, beginner coding community, web development curriculum community, engineering students discord, study group discord *(needs data)*, homework help discord *(needs data)*, free coding resources community

## 8. Hardware, electronics and smart home (10)
arduino discord, home assistant discord, smart home community discord, zigbee discord server, esp32 community discord, raspberry pi discord *(needs data)*, iot discord server, 3d printing discord *(needs data)*, circuitpython discord, homebridge discord

## 9. Language-specific and regional communities (10) *(needs data)*
french discord servers, spanish discord servers, german discord servers, portuguese discord servers, romanian discord server, japanese language discord, english speaking discord communities, language exchange discord, discord servers by language, regional discord communities

Only publish a language or region page when records carry real `language` or `region` values. Never infer a region from a server's name or from a visitor's IP.

## 10. New and top-rated communities (10)
new discord servers, newly added discord servers, recently added discord communities, top rated discord servers, best discord communities, popular discord servers, discord server reviews, discord server ratings, random discord server, small discord communities

"Top rated" and "reviews" phrases must not be used as claims: ratings on this site are local to each visitor.

## Where to use them
* **Titles/descriptions:** one primary phrase each, written as a sentence a person would click (see `tools/build.mjs`).
* **Category pages:** one per category that has at least 3 real listings.
* **About page:** explain verification and local ratings in plain words; it answers the "discord server reviews" intent honestly.
* **Do not:** repeat phrases in hidden text, create pages with no unique listings, or stuff tags.

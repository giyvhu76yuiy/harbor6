// Static generator: reads public/data/*.json and writes crawlable pages, sitemap.xml, robots.txt, 404.html.
// Usage: SITE_URL=https://your-domain node tools/build.mjs      (no dependencies, Node 18+)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = process.env.HARBOR_ROOT ? path.resolve(process.env.HARBOR_ROOT) : path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), PUB = path.join(ROOT, 'public');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'site.config.json'), 'utf8'));
const SITE = (process.env.SITE_URL || cfg.siteUrl).replace(/\/+$/, ''), NAME = cfg.siteName || 'Harbor', EMAIL = process.env.REPORT_EMAIL ?? cfg.reportEmail ?? '';
const GSV = (process.env.GOOGLE_SITE_VERIFICATION ?? cfg.googleSiteVerification ?? '').replace(/[^\w-]/g, '');
if (!/^https?:\/\/[^\s/]+/.test(SITE)) throw new Error('SITE_URL must be an absolute URL');
if (SITE === 'https://example.com') console.warn('WARN  SITE_URL is the placeholder https://example.com: set SITE_URL before deploying.');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const norm = s => String(s || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const slug = s => norm(s).replace(/ /g, '-') || 'other';
const INV = /^https:\/\/(?:discord\.gg|discord\.com\/invite)\/([A-Za-z0-9-]{2,32})$/;
const clip = (s, n) => { s = String(s).replace(/\s+/g, ' ').trim(); return s.length <= n ? s : s.slice(0, n - 1).replace(/\s+\S*$/, '') + '…'; };

/* ---- load + validate (same rules as the browser app) ---- */
const manifest = JSON.parse(fs.readFileSync(path.join(PUB, 'data/manifest.json'), 'utf8'));
const recs = [], ids = new Set(), codes = new Set(), names = new Set(), problems = [];
for (const f of manifest.files || []) {
  if (!/^[\w.-]+\.json$/.test(f.file)) { problems.push('bad manifest entry ' + f.file); continue; }
  let list; try { list = JSON.parse(fs.readFileSync(path.join(PUB, 'data', f.file), 'utf8')); } catch (e) { problems.push(`${f.file}: ${e.message}`); continue; }
  if (!Array.isArray(list)) { problems.push(`${f.file}: not an array`); continue; }
  for (const r of list) {
    if (r && r.status === 'expired') continue;           // confirmed-dead invites are not published
    if (!r || typeof r.name !== 'string' || !r.name.trim() || !/^[a-z0-9-]{1,80}$/.test(r.id || '')) { problems.push(`${f.file}: skipped invalid record ${JSON.stringify(r && r.id)}`); continue; }
    const m = INV.exec(r.inviteUrl || ''), code = m && m[1].toLowerCase(), key = norm(r.name) + '|' + norm(r.language);
    if (ids.has(r.id) || (code && codes.has(code)) || names.has(key)) { problems.push(`${f.file}: duplicate ${r.id}`); continue; }
    if (!m) problems.push(`${r.id}: invalid invite URL, page will have no join button`);
    ids.add(r.id); if (code) codes.add(code); names.add(key);
    recs.push({ ...r, category: r.category || 'Other', tags: (r.tags || []).slice(0, 12), invite: m ? r.inviteUrl : null, verified: r.status === 'verified' && !!r.lastVerified });
  }
}
const cats = new Map(); for (const r of recs) { const s = slug(r.category); if (!cats.has(s)) cats.set(s, { name: r.category, slug: s, list: [] }); cats.get(s).list.push(r); }
for (const c of cats.values()) c.list.sort((a, b) => a.name.localeCompare(b.name));

/* ---- templates ---- */
const sprite = '<svg width="0" height="0" style="position:absolute" aria-hidden="true"></svg>';
const icon = n => `<svg class="ic" aria-hidden="true"><use href="/assets/icons.svg#i-${n}"/></svg>`;
const FAV = `<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='8' fill='%23007aff'/%3E%3Cpath d='M16 6v13m-7-3a7 7 0 0014 0M11 9h10' stroke='%23fff' stroke-width='2.4' fill='none' stroke-linecap='round'/%3E%3C/svg%3E">`;
function page({ title, desc, url, body, head = '', ld = null, scripts = [], robots = 'index,follow', type = 'website' }) {
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><meta name="robots" content="${robots}">${GSV ? `<meta name="google-site-verification" content="${GSV}">` : ''}
<link rel="canonical" href="${esc(SITE + url)}"><meta name="theme-color" content="#f5f5f7" media="(prefers-color-scheme: light)"><meta name="theme-color" content="#000000" media="(prefers-color-scheme: dark)">
<meta property="og:site_name" content="${esc(NAME)}"><meta property="og:type" content="${type}"><meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}"><meta property="og:url" content="${esc(SITE + url)}">
<meta name="twitter:card" content="summary"><meta name="twitter:title" content="${esc(title)}"><meta name="twitter:description" content="${esc(desc)}">
${FAV}<link rel="stylesheet" href="/assets/harbor.css">${head}${ld ? `<script type="application/ld+json">${JSON.stringify(ld).replace(/</g, '\\u003c')}</script>` : ''}</head>
<body>${sprite}<a class="skip" href="#main">Skip to content</a>
${body}
<footer class="ftr"><nav aria-label="Browse categories"><strong>Categories:</strong> ${[...cats.values()].map(c => `<a href="/c/${c.slug}/">${esc(c.name)}</a>`).join('')}<br><a href="/">Search</a><a href="/about/">About &amp; how ratings work</a></nav></footer>
<div class="bd" id="bd" data-a="close"></div><div class="sh" id="sh" role="dialog" aria-modal="true" aria-labelledby="ft"><div class="gb"></div><div class="shc" id="shc"></div></div><div id="toast" role="status"></div>
${scripts.map(s => `<script src="${s}" defer></script>`).join('')}</body></html>`;
}
const searchBar = (menu) => `<form class="fs" id="fs" action="/" method="get" role="search"><div class="srch"><svg class="ic" aria-hidden="true"><use href="/assets/icons.svg#i-search"/></svg><input id="q" name="q" type="search" placeholder="Search millions of Discord servers…" enterkeyhint="search" aria-label="Search Discord servers" autocomplete="off" maxlength="100" role="combobox" aria-expanded="false" aria-controls="sgl" aria-autocomplete="list">${menu ? `<button class="ib" type="button" data-a="menu" aria-label="Filters"><svg class="ic" aria-hidden="true"><use href="/assets/icons.svg#i-menu"/></svg><i id="fc" hidden></i></button>` : ''}</div>${menu ? '<div class="sgl" id="sgl" role="listbox" hidden></div>' : ''}</form>`;
const crumb = (items) => ({ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: items.map((x, i) => ({ '@type': 'ListItem', position: i + 1, name: x[0], item: SITE + x[1] })) });
const out = (p, html) => { const f = path.join(PUB, p); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, html); };
const host = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return 'source'; } };
const similar = r => recs.filter(o => o.id !== r.id).map(o => ({ o, s: o.tags.filter(t => r.tags.includes(t)).length * 2 + (o.category === r.category ? 1 : 0) + (o.language && o.language === r.language ? .5 : 0) })).filter(x => x.s > 0).sort((a, b) => b.s - a.s || a.o.name.localeCompare(b.o.name)).slice(0, 4).map(x => x.o);

/* ---- home ---- */
out('index.html', page({
  title: `${NAME}: search Discord servers by name, topic and category`,
  desc: `Search ${recs.length} Discord servers listed by their official sites and curated developer lists. Filter by category and language, then read each server's description before you join.`,
  url: '/', scripts: ['/assets/app.js'],
  ld: { '@context': 'https://schema.org', '@type': 'WebSite', name: NAME, url: SITE + '/', potentialAction: { '@type': 'SearchAction', target: { '@type': 'EntryPoint', urlTemplate: SITE + '/?q={search_term_string}' }, 'query-input': 'required name=search_term_string' } },
  body: `${searchBar(true)}<main id="main" class="view on"><div class="wrap"><h1 class="sr">Search Discord servers</h1><div class="rl" id="rl"></div><div class="grid" id="grid" aria-live="polite"></div><div class="more" id="more" style="text-align:center;color:var(--t2);padding:24px 0;min-height:48px"></div><noscript><p>Harbor needs JavaScript for search. Browse by category instead: ${[...cats.values()].map(c => `<a href="/c/${c.slug}/">${esc(c.name)}</a>`).join(', ')}.</p></noscript></div></main>`
}));

/* ---- server pages ---- */
for (const r of recs) {
  const sim = similar(r), cat = slug(r.category);
  const desc = clip(`${r.description || r.name} Category: ${r.category}. ${r.language ? 'Language: ' + r.language + '.' : ''}`, 158);
  const stat = r.verified ? `Invite verified on ${esc(r.lastVerified)}` : 'Not verified: the invite has not been checked by Harbor';
  out(`s/${r.id}/index.html`, page({
    title: `${r.name} Discord server: description, invite and reviews | ${NAME}`, desc, url: `/s/${r.id}/`, scripts: ['/assets/server.js'], type: 'article',
    ld: crumb([[NAME, '/'], [r.category, `/c/${cat}/`], [r.name, `/s/${r.id}/`]]),
    head: r.reviews && r.reviews.length ? '' : '',
    body: `${searchBar(false)}<main id="main" class="wrap" data-id="${esc(r.id)}" data-report-email="${esc(EMAIL)}"><div class="pg">
<nav class="bc" aria-label="Breadcrumb"><a href="/">${NAME}</a><span>/</span><a href="/c/${cat}/">${esc(r.category)}</a><span>/</span><span aria-current="page">${esc(r.name)}</span></nav>
<h1>${esc(r.name)}</h1>
<div class="meta"><a href="/c/${cat}/">${esc(r.category)}</a>${r.language ? `<span>${esc(r.language)}</span>` : ''}${r.region ? `<span>${esc(r.region)}</span>` : ''}<span class="warn">${stat}</span></div>
<p>${esc(r.description) || 'This listing has no description.'}</p>
${r.tags.length ? `<div class="tgs" aria-label="Tags">${r.tags.map(t => `<a href="/?q=${encodeURIComponent(t)}">${esc(t)}</a>`).join('')}</div>` : ''}
<div class="cta">${r.invite ? `<a class="btn p" href="${esc(r.invite)}" target="_blank" rel="noopener noreferrer nofollow" style="padding:0 24px;height:48px">Open Discord invite (external)</a>` : '<span class="note">No valid invite link is available for this listing.</span>'}${r.website ? `<a href="${esc(r.website)}" target="_blank" rel="noopener noreferrer">Official website (external)</a>` : ''}</div>
<p class="note">The invite opens discord.gg, a different site. Listing source: <a href="${esc(r.source)}" rel="noopener noreferrer nofollow" target="_blank">${esc(host(r.source))}</a>${r.lastVerified ? '' : '. Harbor has not checked whether this invite still works'}.${r.discoveryDate ? ` Added ${esc(r.discoveryDate)}.` : ''}</p>
<section aria-labelledby="rt"><h2 id="rt">Rate and review</h2>
<p class="note" id="rsum" aria-live="polite"></p>
<div id="stars" class="stars" role="radiogroup" aria-label="Your rating"></div>
<div class="fm"><label class="sr" for="rtext">Optional written review</label><textarea class="in" id="rtext" maxlength="600" placeholder="Optional review (up to 600 characters, no links)"></textarea><div class="cnt" id="cnt">0 / 600</div>
<div class="cta" style="margin:0"><button class="btn p" id="rsubmit" type="button" style="padding:0 24px;height:44px">Save rating</button><button class="btn s" id="rdel" type="button" hidden style="padding:0 16px;height:44px">Remove mine</button></div></div>
<p class="msg" id="msg" role="status"></p>
<p class="note">Ratings and reviews are saved on this device only. They are not shared with other visitors, are not a community score, and can be cleared or edited by anyone using this browser.</p>
<div class="rl" style="margin-top:16px"><h3>Ratings on this device</h3><select class="in" id="rsort" aria-label="Sort reviews" hidden style="width:auto;min-height:36px"><option value="new">Newest</option><option value="high">Highest</option><option value="low">Lowest</option><option value="detail">Most detailed</option></select></div><div id="rlist"></div>
${r.reviews && r.reviews.length ? `<script type="application/json" id="base-reviews">${JSON.stringify(r.reviews.slice(0, 50).map(v => ({ rating: Math.min(5, Math.max(1, parseInt(v.rating) || 1)), text: String(v.text || '').slice(0, 600), date: String(v.date || '') }))).replace(/</g, '\\u003c')}</script>` : ''}
</section>
<section aria-labelledby="rp"><h2 id="rp">Report this listing</h2><button class="btn s" id="rpt-btn" type="button" style="padding:0 16px;height:44px">Report a problem</button>
<div id="rpt" class="fm" hidden><label for="rpt-reason" class="sr">Reason</label><select class="in" id="rpt-reason"><option>Invite does not work</option><option>Misleading or wrong description</option><option>Spam or scam</option><option>Other</option></select><label for="rpt-note" class="sr">Details</label><textarea class="in" id="rpt-note" maxlength="300" placeholder="Details (optional, 300 characters)"></textarea><button class="btn p" id="rpt-send" type="button" style="padding:0 24px;height:44px">Save report</button><p class="note" id="rpt-msg" role="status">Harbor is a static site with no server, so reports are only saved in this browser. They are not sent anywhere.</p><a id="rpt-mail" hidden>Email this report</a></div></section>
${sim.length ? `<section aria-labelledby="sm"><h2 id="sm">Similar servers</h2><div class="sim">${sim.map(o => `<a href="/s/${o.id}/"><b>${esc(o.name)}</b><small>${esc(o.category)}${o.language ? ' · ' + esc(o.language) : ''}</small></a>`).join('')}</div></section>` : ''}
</div></main>`
  }));
}

/* ---- category pages ---- */
for (const c of cats.values()) out(`c/${c.slug}/index.html`, page({
  title: `${c.name} Discord servers: ${c.list.length} listed communities | ${NAME}`,
  desc: clip(`${c.list.length} ${c.name} Discord servers with descriptions and invite links, including ${c.list.slice(0, 3).map(r => r.name).join(', ')}.`, 158), url: `/c/${c.slug}/`,
  ld: crumb([[NAME, '/'], [c.name, `/c/${c.slug}/`]]),
  body: `${searchBar(false)}<main id="main" class="wrap"><div class="pg"><nav class="bc" aria-label="Breadcrumb"><a href="/">${NAME}</a><span>/</span><span aria-current="page">${esc(c.name)}</span></nav><h1>${esc(c.name)} Discord servers</h1>
<p>${c.list.length} server${c.list.length > 1 ? 's' : ''} in this category. None are verified by ${NAME}; each page names where the listing came from.</p><ul class="ol">${c.list.map(r => `<li><a href="/s/${r.id}/"><b>${esc(r.name)}</b></a>${r.language ? ` <small>${esc(r.language)}</small>` : ''}<p>${esc(clip(r.description, 170))}</p></li>`).join('')}</ul></div></main>`
}));

/* ---- about + 404 ---- */
out('about/index.html', page({
  title: `About ${NAME}: how listings and local ratings work`, desc: `How ${NAME} sources its Discord server listings, what “not verified” means, and why ratings stay on your device.`, url: '/about/',
  body: `${searchBar(false)}<main id="main" class="wrap"><div class="pg"><h1>About ${NAME}</h1>
<h2>Where listings come from</h2><p>Each listing comes from a public list that the page names, for example a developer list that only accepts servers linked from official sites. ${NAME} does not scrape Discord, invent servers or buy placements. The directory grows when new data files are added.</p>
<h2>What “not verified” means</h2><p>${NAME} has no server that can check invites. A listing is marked verified only when a data file records a real check date. An invite that looks valid can still be expired.</p>
<h2>Ratings and reviews</h2><p>Ratings are stored in your browser. Nobody else can see them and ${NAME} cannot count them. There are no accounts and no tracking. Because the data is local, it is not tamper-proof.</p>
<h2>Limits of a static site</h2><p>A static site cannot crawl Discord, run scheduled jobs or share data between visitors. Spam limits (cooldowns, length limits, link blocking) only apply inside one browser.</p></div></main>`
}));
out('404.html', page({ title: `Page not found | ${NAME}`, desc: 'This page does not exist.', url: '/404.html', robots: 'noindex',
  body: `${searchBar(false)}<main id="main" class="wrap"><div class="pg"><h1>Page not found</h1><p>That page does not exist. Search for a server or <a href="/">go to the start page</a>.</p></div></main>` }));

/* ---- sitemap + robots ---- */
const urls = [['/', manifest.updated], ['/about/', manifest.updated], ...[...cats.values()].map(c => [`/c/${c.slug}/`, manifest.updated]), ...recs.map(r => [`/s/${r.id}/`, r.discoveryDate || manifest.updated])];
out('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(([u, d]) => `<url><loc>${esc(SITE + u)}</loc>${d ? `<lastmod>${esc(d)}</lastmod>` : ''}</url>`).join('\n')}\n</urlset>\n`);
out('robots.txt', `User-agent: *\nAllow: /\n\nSitemap: ${SITE}/sitemap.xml\n`);
out('_headers', `/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n  X-Frame-Options: DENY\n  Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'\n/data/*\n  Cache-Control: public, max-age=3600\n/assets/*\n  Cache-Control: public, max-age=86400\n`);
console.log(`built ${recs.length} servers, ${cats.size} categories, ${urls.length} sitemap URLs for ${SITE}`);
problems.forEach(p => console.warn('WARN  ' + p));

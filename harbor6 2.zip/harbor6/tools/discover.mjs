// Automatic discovery for a static site. Runs on a schedule in GitHub Actions (free), NOT in the browser and NOT on a server of yours:
//   read sources -> queue new invite URLs -> verify with Discord's public invite lookup -> write new records to public/data/ -> commit -> Cloudflare Pages redeploys.
// Only real data is written: names/descriptions come from Discord's response, lastVerified is set only when a lookup succeeded today.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const HERE = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const INV = /^https:\/\/(?:discord\.gg|discord\.com\/invite)\/([A-Za-z0-9-]{2,32})$/;
const RX = /(?:https?:\/\/)?(?:www\.)?(?:discord\.gg|discord(?:app)?\.com\/invite)\/([A-Za-z0-9-]{2,32})(?![A-Za-z0-9-])/gi;
const SHARD_MAX = 2000, HASH = /^[A-Za-z0-9_]{8,64}$/;
export const extractCodes = t => [...new Set([...String(t).matchAll(RX)].map(m => m[1]))];
const norm = s => String(s || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const slug = s => norm(s).replace(/ /g, '-').slice(0, 70).replace(/^-|-$/g, '');
const clean = (s, n) => String(s || '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u200B-\u200F\u202A-\u202E]/g, '').replace(/\s+/g, ' ').trim().slice(0, n);
const sleep = ms => new Promise(r => setTimeout(r, ms));

/** Discord's public invite lookup. Returns {kind: ok|gone|rate|temp|reject, ...}. */
export async function verifyInvite(code, fetchImpl, ua) {
  let r;
  try { r = await fetchImpl(`https://discord.com/api/v10/invites/${encodeURIComponent(code)}?with_counts=true`, { headers: { 'user-agent': ua, accept: 'application/json' }, signal: AbortSignal.timeout(8000) }); }
  catch (e) { return { kind: 'temp', error: String(e.message || e).slice(0, 100) }; }
  if (r.status === 429) return { kind: 'rate', retryAfter: (Number(r.headers.get('retry-after')) || 5) * 1000 };
  if (r.status === 404) return { kind: 'gone' };
  if (r.status === 403) return { kind: 'gone' };
  if (r.status >= 500 || r.status === 408) return { kind: 'temp', error: 'http ' + r.status };
  if (!r.ok) return { kind: 'reject', error: 'http ' + r.status };
  let j; try { j = await r.json(); } catch { return { kind: 'temp', error: 'bad json' }; }
  const g = j && j.guild;
  if (!g || !/^\d{5,25}$/.test(String(g.id)) || !g.name) return { kind: 'reject', error: 'not a server invite' };
  return { kind: 'ok', guild: { id: String(g.id), name: clean(g.name, 100), description: clean(g.description, 500), nsfw: g.nsfw === true || g.nsfw_level === 1 || g.nsfw_level === 3 } };
}

async function fetchSource(src, fetchImpl, token, ua) {
  if (src.type === 'github-readme') {            // GitHub's documented API for a repository README
    if (!/^[\w.-]+\/[\w.-]+$/.test(src.repo || '')) throw new Error('bad repo');
    const r = await fetchImpl(`https://api.github.com/repos/${src.repo}/readme`, { headers: { accept: 'application/vnd.github.raw+json', 'user-agent': ua, ...(token ? { authorization: 'Bearer ' + token } : {}) }, signal: AbortSignal.timeout(15000) });
    if (!r.ok) throw new Error('github http ' + r.status);
    return extractCodes((await r.text()).slice(0, 2_000_000));
  }
  if (src.type === 'urls') return (src.urls || []).flatMap(u => extractCodes(u));
  throw new Error('unknown source type ' + src.type);
}

export async function discover({ root = HERE, fetchImpl = fetch, today = new Date().toISOString().slice(0, 10), env = process.env, log = console.log, sleepFn = sleep } = {}) {
  const cfg = JSON.parse(fs.readFileSync(path.join(root, 'discovery/sources.json'), 'utf8')), L = { ...cfg.limits, ...(env.DISCOVERY_RATE ? { ratePerSec: Number(env.DISCOVERY_RATE) } : {}) };
  const ua = `HarborIndexer/6 (+${env.HARBOR_CONTACT || 'set HARBOR_CONTACT'})`;
  const stateFile = path.join(root, 'discovery/state.json'), state = fs.existsSync(stateFile) ? JSON.parse(fs.readFileSync(stateFile, 'utf8')) : {};
  state.sources ||= {}; state.cands ||= {}; state.misses ||= {};
  const dataDir = path.join(root, 'public/data'), mf = path.join(dataDir, 'manifest.json'), manifest = JSON.parse(fs.readFileSync(mf, 'utf8'));
  const shards = new Map(); for (const f of manifest.files) shards.set(f.file, JSON.parse(fs.readFileSync(path.join(dataDir, f.file), 'utf8')));
  const all = () => [...shards.values()].flat(), touched = new Set();
  const S = { sources: {}, found: 0, queued: 0, added: 0, held: 0, nsfw: 0, rejected: 0, verified: 0, expired: 0, tempErrors: 0, rateLimited: false };
  const nowSec = () => Math.floor(Date.now() / 1000);
  /* simple pacing: slots reserved up front so concurrent workers cannot burst */
  let slot = 0, pause = 0, rate = L.ratePerSec;
  const take = async () => { const t = Date.now(), at = Math.max(slot, pause, t); slot = at + 1000 / rate; if (at > t) await sleepFn(at - t); };
  const lookup = async code => { await take(); const v = await verifyInvite(code, fetchImpl, ua); if (v.kind === 'rate') { S.rateLimited = true; rate = Math.max(1, Math.floor(rate / 2)); pause = Date.now() + Math.min(v.retryAfter, 60000); } return v; };
  const pool = async (items, fn) => { let i = 0; await Promise.all(Array.from({ length: Math.min(L.concurrency, items.length) }, async () => { while (i < items.length && !S.rateLimited) await fn(items[i++]); })); };

  /* 1. recheck existing records (also fills guildId and a real lastVerified) */
  const due = all().filter(r => INV.test(r.inviteUrl || '') && r.status !== 'expired' && (!r.lastVerified || (Date.parse(today) - Date.parse(r.lastVerified)) / 864e5 >= L.recheckAfterDays))
    .sort((a, b) => String(a.lastVerified || '').localeCompare(String(b.lastVerified || ''))).slice(0, L.maxRechecksPerRun);
  await pool(due, async r => {
    const v = await lookup(INV.exec(r.inviteUrl)[1]);
    if (v.kind === 'ok') { r.lastVerified = today; r.status = 'verified'; r.guildId = v.guild.id; delete state.misses[r.id]; S.verified++; touched.add(r.id); }
    else if (v.kind === 'gone' || v.kind === 'reject') { const n = (state.misses[r.id] || 0) + 1; state.misses[r.id] = n; if (n >= L.expireAfterMisses) { r.status = 'expired'; S.expired++; } touched.add(r.id); }
    else if (v.kind === 'temp') S.tempErrors++;                                  // a timeout never changes a listing
  });

  /* 2. read sources (skipping any in backoff), queue new invite codes */
  const known = new Set(all().map(r => (INV.exec(r.inviteUrl || '') || [])[1]?.toLowerCase()).filter(Boolean));
  for (const src of cfg.sources) {
    const st = state.sources[src.name] ||= { failures: 0, backoffUntil: 0 };
    if (st.backoffUntil > nowSec()) { S.sources[src.name] = 'backoff'; continue; }
    try {
      const codes = await fetchSource(src, fetchImpl, env.GITHUB_TOKEN, ua); let q = 0; S.found += codes.length;
      for (const c of codes) { const k = c.toLowerCase(); if (known.has(k) || state.cands[k]) continue; state.cands[k] = { s: 'queued', src: src.name, seen: today, tries: 0, next: 0 }; q++; }
      S.queued += q; S.sources[src.name] = `ok, ${codes.length} found, ${q} new`; st.failures = 0; st.lastOk = today;
    } catch (e) { st.failures++; st.backoffUntil = nowSec() + Math.min(21600, 600 * 2 ** st.failures); st.lastError = String(e.message).slice(0, 120); S.sources[src.name] = 'error: ' + st.lastError; }
  }

  /* 3. verify queued candidates and write real records */
  const todo = Object.entries(state.cands).filter(([, c]) => (c.s === 'queued' && c.next <= nowSec()) || (c.s === 'held' && (Date.parse(today) - Date.parse(c.seen)) / 864e5 >= 30)).slice(0, L.maxNewChecksPerRun);
  const guilds = new Set(all().map(r => r.guildId).filter(Boolean)), ids = new Set(all().map(r => r.id)), names = new Set(all().map(r => norm(r.name) + '|' + norm(r.language)));
  const fresh = [];
  await pool(todo, async ([code, c]) => {
    const src = cfg.sources.find(s => s.name === c.src) || {}, v = await lookup(code);
    if (v.kind === 'rate') return;
    if (v.kind === 'temp') { S.tempErrors++; c.tries++; c.next = nowSec() + Math.min(86400, 900 * 2 ** c.tries); if (c.tries >= 5) c.s = 'failed'; return; }
    if (v.kind !== 'ok') { c.s = 'rejected'; S.rejected++; return; }
    const g = v.guild;
    if (guilds.has(g.id)) { c.s = 'duplicate'; return; }
    if (g.nsfw) { c.s = 'nsfw'; S.nsfw++; return; }
    if (g.description.length < L.minDescriptionLength) { c.s = 'held'; c.seen = today; S.held++; return; }   // no thin pages: wait for a real description
    let id = slug(g.name) || 'server'; if (ids.has(id)) id = `${id.slice(0, 64)}-${g.id.slice(-4)}`; if (ids.has(id) || names.has(norm(g.name) + '|' + norm(src.language))) { c.s = 'duplicate'; return; }
    ids.add(id); guilds.add(g.id); names.add(norm(g.name) + '|' + norm(src.language));
    fresh.push({ id, name: g.name, description: g.description, inviteUrl: 'https://discord.gg/' + code, category: src.category || 'Other', tags: src.tags || [], language: src.language || null, region: null, website: null,
      source: `${src.name}${src.url ? ' (' + src.url + ')' : ''}`, listedAs: 'auto-discovered', guildId: g.id, lastVerified: today, ratingAverage: null, ratingCount: 0, discoveryDate: today, status: 'verified' });
    c.s = 'done'; S.added++;
  });

  /* 4. write: new records go to the newest auto shard; edited records go back to their own shard */
  if (fresh.length) {
    let name = [...shards.keys()].filter(f => /^servers-auto-\d+\.json$/.test(f)).sort().pop();
    if (!name || shards.get(name).length >= SHARD_MAX) { name = `servers-auto-${String([...shards.keys()].filter(f => f.startsWith('servers-auto-')).length + 1).padStart(3, '0')}.json`; shards.set(name, []); manifest.files.push({ file: name, count: 0 }); }
    for (const r of fresh) { if (shards.get(name).length >= SHARD_MAX) { name = `servers-auto-${String([...shards.keys()].filter(f => f.startsWith('servers-auto-')).length + 1).padStart(3, '0')}.json`; shards.set(name, []); manifest.files.push({ file: name, count: 0 }); } shards.get(name).push(r); }
    for (const f of manifest.files) if (shards.get(f.file)) { f.count = shards.get(f.file).length; touched.add('shard:' + f.file); }
  }
  for (const [file, list] of shards) if (fresh.length || list.some(r => touched.has(r.id))) fs.writeFileSync(path.join(dataDir, file), JSON.stringify(list, null, 1) + '\n');
  if (fresh.length || S.expired) { manifest.updated = today; fs.writeFileSync(mf, JSON.stringify(manifest, null, 1) + '\n'); }
  state.lastRun = today; fs.writeFileSync(stateFile, JSON.stringify(state, null, 1) + '\n');
  log(`discovery: ${S.added} added, ${S.queued} queued, ${S.held} held (no description), ${S.nsfw} adult skipped, ${S.rejected} rejected, ${S.verified} rechecked ok, ${S.expired} expired, ${S.tempErrors} temp errors${S.rateLimited ? ', RATE LIMITED (stopped early)' : ''}`);
  for (const [k, v] of Object.entries(S.sources)) log(`  source ${k}: ${v}`);
  return S;
}
if (import.meta.url === `file://${process.argv[1]}`) discover().catch(e => { console.error(e); process.exit(1); });

# Harbor 6 (static)

A static Discord server directory and search engine. **No backend, no database, no accounts, no paid services, no framework.** It runs on Cloudflare Pages (or any static host).

The starting dataset has **91 servers** (not 100). Each comes from a public list that restricts itself to officially linked servers, or from a Discord/community page that names the official invite. See "Dataset honesty" below.

## Deploy on Cloudflare Pages
1. Put this folder in a Git repo and create a Pages project from it (or use Direct Upload with the `public/` folder).
2. Framework preset: none. **Build command:** `node tools/build.mjs`. **Build output directory:** `public`.
3. Environment variable: `SITE_URL=https://your-domain` (needed for canonical URLs and the sitemap). Optional: `GOOGLE_SITE_VERIFICATION`, `REPORT_EMAIL`.
4. Direct Upload without a build step? Run `SITE_URL=https://your-domain node tools/build.mjs` locally first, then upload `public/`.

`public/_headers` (generated) sets a strict CSP, caching and `nosniff`. `public/404.html` is used automatically for unknown URLs.

## What is in the box
| Path | Purpose |
|---|---|
| `public/index.html` | Search page (generated). Search bar, results, filter sheet. |
| `public/assets/app.js` | Search, ranking, filters, suggestions, infinite scroll, lazy data loading. |
| `public/assets/server.js` | Server-page ratings, reviews and reports (local only). |
| `public/data/manifest.json`, `servers-001.json`, `schema.json` | Dataset files and record schema. |
| `public/s/<id>/`, `public/c/<category>/`, `public/about/` | Generated crawlable pages. |
| `public/sitemap.xml`, `robots.txt`, `404.html`, `_headers` | Generated SEO and hosting files. |
| `tools/build.mjs` | The generator. No dependencies. |
| `docs/SEO_KEYWORDS.md` | 100-phrase keyword plan. |
| `tools/discover.mjs`, `discovery/sources.json`, `.github/workflows/discover.yml` | Automatic discovery. |


## Automatic discovery (no server, no cost)
A static site cannot crawl by itself, so discovery runs **outside** it, on a schedule, in GitHub Actions (free for normal use). The loop:
`.github/workflows/discover.yml` (every 6 hours) → `node tools/discover.mjs` → new records are committed to `public/data/` → Cloudflare Pages, connected to the same Git repo, rebuilds and deploys.
What `tools/discover.mjs` does each run:
1. **Rechecks** the oldest listings (150 per run, each at most weekly): a successful lookup sets a real `lastVerified` date and the Discord `guildId`. A missing invite is confirmed on two separate runs before the listing is marked `expired` and hidden. Timeouts and errors never change a listing.
2. **Reads sources** from `discovery/sources.json` (ships with two public GitHub lists, read through GitHub's README API). A failing source backs off 20 min doubling to 6 h and does not block the others.
3. **Verifies new invites** with Discord's public invite lookup (400 per run, 5 per second by default, halves and pauses on HTTP 429, stops the run early if limited). Records are created only from what Discord returns: real name and description, deduplicated by server ID, invite code and name. Adult servers are skipped. A server with no real description is held 30 days instead of getting a thin page.
4. Writes `public/data/servers-auto-NNN.json` (2,000 per file, manifest updated). Category, tags and language come from the **source's** settings, never guessed.
Setup: push this folder to a GitHub repo → Actions tab → enable workflows → (optional) repository variable `HARBOR_CONTACT` = your email or URL for the User-Agent → run "discover" once with "Run workflow". In Cloudflare: Pages → Connect to Git (not Direct Upload), so each commit redeploys.
Raise speed with the `DISCOVERY_RATE` environment variable (default 5/s) and the limits in `discovery/sources.json`. The only honest cap on "new servers per second" is how many **new** invite links your sources contain and Discord's rate limits; it will not reach any fixed number.
Adding a source: `{"type":"github-readme","repo":"owner/name",...}` or `{"type":"urls","urls":[...]}` in `discovery/sources.json`. Only add sources whose terms allow it. Check Discord's current developer terms for the invite lookup before running at volume. Never guess invite codes.
Not tested here: a real run against GitHub and Discord (this environment has no outside network). The logic is covered by mocked tests, and the first scheduled run is the real test.

## Adding servers by hand
1. Create `public/data/servers-002.json`: an array of records (see `data/schema.json`).
   `{"id":"my-server","name":"My Server","description":"What it really is.","inviteUrl":"https://discord.gg/abc123","category":"Gaming","tags":["x"],"language":"English","region":null,"source":"where you found it","lastVerified":null,"status":"unverified","discoveryDate":"2026-11-01"}`
2. Add `{"file":"servers-002.json","count":N}` to `files` in `data/manifest.json`.
3. Run `node tools/build.mjs` (or let Cloudflare do it) and deploy.
Rules the app and the build both enforce: `id` is a lowercase slug and unique; duplicates are dropped by id, by invite code, and by normalized name + language; invalid invites keep the listing but remove the Join button; malformed rows are skipped and reported. Keep each file to about 2,000 records. The first file loads on page load; the others load as people scroll, and all load when someone searches or filters, so results are complete.
Set `lastVerified` and `"status":"verified"` **only** if you actually checked the invite that day.

## Features that genuinely work
Search by name, description, tags, category, language and region (partial, case-insensitive, accent-insensitive, one-typo tolerance, swaps like "pyhton"); suggestions and local recent searches; Best match / Top rated / Newest / A to Z; category, language, region and rating filters (language and region only appear when the data varies); random server; infinite scroll; server pages with description, tags, status, invite, source link, similar servers, local rating and review form, report form; per-page SEO metadata, sitemap, robots.txt, 404; light/dark themes; no bottom navigation.
Ranking (Best match) uses name 40%, description 25%, tags/category 20%, language/region 10%, data completeness 5%. Description matches count once per word, so keyword stuffing does not help. Top rated is a Bayesian average (prior 3.5, weight 5) over dataset ratings plus this device's rating. Trending is deliberately absent: there is no shared activity data.

## Limits of a static-only site
* The site itself cannot crawl or run jobs. Automatic growth comes from the GitHub Actions job above and needs a Git-connected deploy. No live member counts.
* Visitors' browsers never call Discord. Invites are only checked by the scheduled job; until it has run, listings show as not verified.
* Ratings, reviews and reports live in each visitor's browser. They are not shared, not a global score, and can be cleared or edited by the visitor.
* No server means no IP rate limits, no global one-vote-per-person, no shared moderation. Real abuse protection would need infrastructure this project excludes.
* A trending sort would need shared visit data, which does not exist.
* Search scans loaded records in memory. That is fine to tens of thousands of records; beyond that, split by category or add a prebuilt index.

## Anti-spam: what is real
Operational (inside one browser): 250 ms search debounce; 15 s cooldown between saves; max 5 saves per 10 minutes; one rating per server (edits update it); 600-character limit; control characters stripped; links in reviews rejected; identical text on 3 servers rejected; report once per server per day; all text inserted with `textContent`; invite URLs validated and opened with `rel="noopener noreferrer nofollow"`. Not provided: distributed-bot defense, global anti-raid, IP-based limits, fingerprinting (deliberately none), tamper-proof storage.

## SEO and Google Search Console
Each server and category page is pre-rendered HTML with a unique title, description, canonical, Open Graph tags and breadcrumb data. The home page has WebSite search markup. No rating markup is used because there is no global rating. Not verified: that Google has indexed anything; rankings are not promised.
1. Deploy with the real `SITE_URL`.
2. Search Console → add property → choose "HTML tag", copy the code, set `GOOGLE_SITE_VERIFICATION` (or `site.config.json`), rebuild, verify.
3. Sitemaps → submit `https://your-domain/sitemap.xml`. Indexing takes days to weeks.
Do not add pages for categories with no real listings; use `docs/SEO_KEYWORDS.md` to plan wording, not to pad.

## Dataset honesty
Sources (read 2026-10-25): the "Official" badge rows of `github.com/mhxion/awesome-discord-communities`; entries of `github.com/ljosberinn/awesome-dev-discord` (requires official links); Discord's own page for Hypixel; `discord.com/invite/valorant`; the Discord wiki entry for Official Fortnite; one third-party article naming `discord.com/invite/minecraft` as the Minecraft Official server. Those lists are years old, so some invites may have expired. The set leans toward developer tools because those lists were the ones that vouch for official status. It has 4 gaming servers, not many. I could not confirm 100.

## Tests
The development test suites (browser and discovery tests) are not part of this deploy package. Not tested by anyone yet: a real Cloudflare deployment and a live discovery run.

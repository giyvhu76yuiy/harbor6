/* Harbor 6 server page: local-only ratings, reviews and reports. Everything is saved in THIS browser (localStorage).
   It is not shared, not tamper-proof and not a global score. No review text is ever inserted as HTML. */
(()=>{
'use strict';
const main=document.querySelector('main[data-id]');if(!main)return;
const id=main.dataset.id,$=s=>main.querySelector(s);
const store={get(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch{return false}}};
const LIMIT=600,COOLDOWN=15e3,BURST=[5,10*60e3];
const clean=s=>String(s||'').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u200B-\u200F\u202A-\u202E]/g,'').replace(/[ \t]+/g,' ').replace(/\n{3,}/g,'\n\n').trim();
const LINK=/(https?:\/\/|www\.|discord\.gg\/|discord(app)?\.com\/invite)/i;
const el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
const star=()=>{const s=document.createElementNS('http://www.w3.org/2000/svg','svg'),u=document.createElementNS('http://www.w3.org/2000/svg','use');s.setAttribute('class','ic');s.setAttribute('aria-hidden','true');u.setAttribute('href','/assets/icons.svg#i-star');s.appendChild(u);return s};
let pick=0,sort='new';
const all=()=>store.get('harbor6.ratings',{});
const base=JSON.parse((document.getElementById('base-reviews')||{textContent:'[]'}).textContent||'[]'); // optional reviews shipped in the dataset
const ro=n=>{const w=el('span','stars ro');w.setAttribute('role','img');w.setAttribute('aria-label',n+' out of 5 stars');for(let i=1;i<=5;i++){const b=el('button',i<=n?'on':'');b.tabIndex=-1;b.appendChild(star());w.appendChild(b)}return w};

function msg(t,err){const m=$('#msg');m.textContent=t;m.className='msg'+(err?' er':'')}
function buildStars(){
 const w=$('#stars');w.textContent='';
 for(let i=1;i<=5;i++){const b=el('button','',null);b.type='button';b.setAttribute('role','radio');b.setAttribute('aria-checked',String(i===pick));b.setAttribute('aria-label',i+' star'+(i>1?'s':''));b.dataset.v=i;b.className=i<=pick?'on':'';b.appendChild(star());b.tabIndex=i===(pick||1)?0:-1;w.appendChild(b)}
}
function render(){
 const mine=all()[id];buildStars();
 $('#rsubmit').textContent=mine?'Update my rating':'Save rating';$('#rdel').hidden=!mine;
 const list=$('#rlist');list.textContent='';
 const rows=[...base.map(r=>({r:r.rating,t:r.text||'',ts:Date.parse(r.date)||0,src:'Dataset'})),...(mine?[{r:mine.r,t:mine.t||'',ts:mine.ts,src:'You (saved on this device)'}]:[])];
 const s=$('#rsort');s.hidden=rows.length<2;
 rows.sort({new:(a,b)=>b.ts-a.ts,high:(a,b)=>b.r-a.r||b.ts-a.ts,low:(a,b)=>a.r-b.r||b.ts-a.ts,detail:(a,b)=>b.t.length-a.t.length}[sort]);
 for(const r of rows){const d=el('div','rv');d.appendChild(ro(r.r));const sm=el('small','',r.src+(r.ts?' · '+new Date(r.ts).toLocaleDateString():''));d.appendChild(sm);if(r.t)d.appendChild(el('p','',r.t));list.appendChild(d)}
 if(!rows.length)list.appendChild(el('p','note','No ratings on this device yet.'));
 const sum=$('#rsum');sum.textContent=mine?`Your rating: ${mine.r} out of 5. Saved on this device only.`:'You have not rated this server on this device.';
}
function submit(){
 const text=clean($('#rtext').value),now=Date.now(),log=store.get('harbor6.subs',[]).filter(t=>now-t<BURST[1]);
 if(!pick)return msg('Choose 1 to 5 stars first.',1);
 if(text.length>LIMIT)return msg(`Reviews are limited to ${LIMIT} characters.`,1);
 if(LINK.test(text))return msg('Links are not allowed in reviews.',1);
 if(log.length&&now-log[log.length-1]<COOLDOWN)return msg(`Please wait ${Math.ceil((COOLDOWN-(now-log[log.length-1]))/1000)} seconds before saving again.`,1);
 if(log.length>=BURST[0])return msg('Too many submissions from this browser in a short time. Try again later.',1);
 const a=all();
 if(text&&Object.entries(a).filter(([k,v])=>k!==id&&v.t&&v.t.toLowerCase()===text.toLowerCase()).length>=2)return msg('That exact text was already used on other servers.',1);
 const prev=a[id];
 if(prev&&prev.r===pick&&(prev.t||'')===text)return msg('Nothing changed.',1);
 a[id]={r:pick,t:text,ts:now,e:!!prev};
 if(!store.set('harbor6.ratings',a))return msg('Could not save: browser storage is unavailable.',1);
 log.push(now);store.set('harbor6.subs',log);
 msg(prev?'Updated. Saved on this device only.':'Thanks! Saved on this device only; other visitors will not see it.');render();
}
function init(){
 const mine=all()[id];if(mine){pick=mine.r;$('#rtext').value=mine.t||''}
 $('#stars').addEventListener('click',e=>{const b=e.target.closest('button');if(b){pick=+b.dataset.v;buildStars();b.focus?.();$('#stars [aria-checked=true]')?.focus()}});
 $('#stars').addEventListener('keydown',e=>{if(!['ArrowRight','ArrowLeft','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();pick=Math.min(5,Math.max(1,(pick||0)+(e.key==='ArrowRight'||e.key==='ArrowUp'?1:-1)));buildStars();$('#stars [aria-checked=true]').focus()});
 $('#rtext').addEventListener('input',()=>{$('#cnt').textContent=$('#rtext').value.length+' / '+LIMIT});
 $('#rsubmit').addEventListener('click',submit);
 $('#rdel').addEventListener('click',()=>{const a=all();delete a[id];store.set('harbor6.ratings',a);pick=0;$('#rtext').value='';msg('Your local rating was removed.');render()});
 $('#rsort').addEventListener('change',e=>{sort=e.target.value;render()});
 $('#rpt-btn').addEventListener('click',()=>{$('#rpt').hidden=!$('#rpt').hidden});
 $('#rpt-send').addEventListener('click',()=>{
  const reason=$('#rpt-reason').value,note=clean($('#rpt-note').value).slice(0,300),rs=store.get('harbor6.reports',[]),now=Date.now(),m=$('#rpt-msg');
  if(rs.some(r=>r.id===id&&now-r.ts<864e5)){m.textContent='You already saved a report for this server today.';return}
  rs.push({id,reason,note,ts:now});store.set('harbor6.reports',rs.slice(-50));
  m.textContent='Saved on this device. Harbor has no server to receive it'+(main.dataset.reportEmail?'; use the email link below to actually send it.':'. To report an invite itself, use Discord’s own reporting tools.');
  const l=$('#rpt-mail');if(l&&main.dataset.reportEmail){l.href='mailto:'+encodeURIComponent(main.dataset.reportEmail).replace('%40','@')+'?subject='+encodeURIComponent('Harbor report: '+id+' ('+reason+')')+'&body='+encodeURIComponent(note);l.hidden=false}
 });
 render();
}
init();
})();

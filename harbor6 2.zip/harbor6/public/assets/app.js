/* Harbor 6: static client-side search. No framework, no backend, no network except same-origin JSON files. */
(()=>{
'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ico=(n,c='')=>`<svg class="ic ${c}" aria-hidden="true"><use href="/assets/icons.svg#i-${n}"/></svg>`;
const norm=s=>String(s||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
const toks=s=>{const n=norm(s);return n?n.split(' '):[]};
const slug=s=>norm(s).replace(/ /g,'-');
const PAGE=24,CAP=2000,DAY=Math.floor(Date.now()/864e5);
const INV=/^https:\/\/(?:discord\.gg|discord\.com\/invite)\/([A-Za-z0-9-]{2,32})$/;
const store={get(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}};

/* ---------- data ---------- */
const S={recs:[],ids:new Set(),codes:new Set(),names:new Set(),files:[],next:0,loading:null,dups:0,bad:0,res:[],shown:0,errors:[]};
function lev(a,b,max){ // Damerau-Levenshtein (adjacent swaps count as one edit), early exit above max
 if(Math.abs(a.length-b.length)>max)return max+1;const d=[];
 for(let i=0;i<=a.length;i++){d[i]=[i];for(let j=1;j<=b.length;j++)d[i][j]=i?0:j}
 for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++){const c=a[i-1]===b[j-1]?0:1;let v=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+c);if(i>1&&j>1&&a[i-1]===b[j-2]&&a[i-2]===b[j-1])v=Math.min(v,d[i-2][j-2]+1);d[i][j]=v}
 return d[a.length][b.length]}
function hash(s){let h=7;for(const c of s)h=(h*31+c.charCodeAt(0))|0;return Math.abs(h)}
function ingest(list,file){
 if(!Array.isArray(list)){S.errors.push(file+': not an array');return 0}
 let n=0;
 for(const r of list){
  try{
   if(r&&r.status==='expired')continue;
   if(!r||typeof r!=='object'||typeof r.name!=='string'||!r.name.trim()||!/^[a-z0-9-]{1,80}$/.test(r.id||'')){S.bad++;continue}
   const m=INV.exec(r.inviteUrl||''),code=m?m[1].toLowerCase():null;
   const key=norm(r.name)+'|'+norm(r.language);
   if(S.ids.has(r.id)||(code&&S.codes.has(code))||S.names.has(key)){S.dups++;continue}
   const tags=(Array.isArray(r.tags)?r.tags:[]).filter(t=>typeof t==='string').slice(0,12).map(t=>t.slice(0,40));
   const o={id:r.id,name:r.name.trim().slice(0,100),desc:String(r.description||'').slice(0,CAP),invite:m?r.inviteUrl:null,cat:String(r.category||'Other').slice(0,40),tags,
    lang:r.language?String(r.language).slice(0,40):'',region:r.region?String(r.region).slice(0,40):'',site:/^https:\/\//.test(r.website||'')?r.website:null,
    status:r.status==='verified'&&r.lastVerified?'verified':'unverified',date:r.discoveryDate||'',ra:Number(r.ratingAverage)>=1&&Number(r.ratingAverage)<=5?Number(r.ratingAverage):null,rc:Math.max(0,parseInt(r.ratingCount)||0)};
   o.nName=norm(o.name);o.tName=o.nName.split(' ');o.tDesc=new Set(toks(o.desc));o.tTag=new Set(tags.flatMap(toks));o.nCat=norm(o.cat);o.tCat=new Set(toks(o.cat));
   o.nLang=norm(o.lang);o.nReg=norm(o.region);o.comp=([o.desc,o.invite,tags.length,o.lang,o.cat!=='Other',o.site].filter(Boolean).length)/6;o.rank=hash(o.id+DAY);
   S.ids.add(o.id);if(code)S.codes.add(code);S.names.add(key);S.recs.push(o);n++;
  }catch(e){S.bad++}
 }
 return n;
}
async function getJSON(u){const r=await fetch(u,{cache:'default'});if(!r.ok)throw new Error(u+' '+r.status);return r.json()}
async function init(){
 try{const m=await getJSON('/data/manifest.json');S.files=(Array.isArray(m.files)?m.files:[]).map(f=>f&&f.file).filter(f=>/^[\w.-]+\.json$/.test(f||''))}
 catch(e){S.errors.push(String(e.message))}
 await loadNext();
}
function loadNext(){ // lazy: one data file at a time
 if(S.loading)return S.loading; if(S.next>=S.files.length)return Promise.resolve(false);
 const f=S.files[S.next++];
 S.loading=getJSON('/data/'+f).then(d=>{const n=ingest(d,f);return n>=0}).catch(e=>{S.errors.push(String(e.message));return false}).finally(()=>{S.loading=null});
 return S.loading;
}
async function loadAll(){while(S.next<S.files.length||S.loading)await loadNext()}

/* ---------- local ratings (this device only) ---------- */
const myRatings=()=>store.get('harbor6.ratings',{});
function bayes(o,mine){let n=o.rc,sum=(o.ra||0)*o.rc;if(mine){n++;sum+=mine.r}const m=5,C=3.5;return n?(n/(n+m))*(sum/n)+(m/(n+m))*C:C-.001}
/* ---------- ranking ---------- */
const F={q:'',cat:'',lang:'',region:'',ver:0,minr:0,sort:'rel'};
function score(o,q){
 const t=toks(q);if(!t.length)return 1;let name=0,desc=0,tag=0,lang=0,all=0;
 for(const w of t){
  let n=0;
  for(const x of o.tName){const s=x===w?1:x.startsWith(w)?.8:(w.length>=3&&x.includes(w))?.5:(w.length>=4&&lev(x,w,w.length>=8?2:1)<=(w.length>=8?2:1))?.4:0;if(s>n)n=s}
  if(n<.8&&w.length>=3&&o.nName.includes(w))n=Math.max(n,.6);
  const d=o.tDesc.has(w)?1:[...o.tDesc].some(x=>w.length>=3&&x.startsWith(w))?.6:0;       // binary presence: repeated keywords add nothing
  let g=o.tTag.has(w)||o.tCat.has(w)?1:[...o.tTag,...o.tCat].some(x=>w.length>=3&&x.startsWith(w))?.7:0;
  const l=(o.nLang&&(o.nLang===w||o.nLang.startsWith(w)&&w.length>=3)||o.nReg&&o.nReg.split(' ').includes(w))?1:0;
  const best=Math.max(n,d,g,l);if(!best)return 0;
  name+=n;desc+=d;tag+=g;lang+=l;all+=best;
 }
 const k=t.length;let phrase=o.nName.includes(norm(q))?.1:0;
 return .40*(name/k)+.25*(desc/k)+.20*(tag/k)+.10*(lang/k)+.05*o.comp+phrase+(all/k)*.01;
}
function compute(){
 const mine=myRatings(),q=F.q.trim(),out=[];
 for(const o of S.recs){
  if(F.cat&&o.cat!==F.cat)continue;if(F.lang&&o.lang!==F.lang)continue;if(F.region&&o.region!==F.region)continue;if(F.ver&&o.status!=='verified')continue;
  if(F.minr){const m=mine[o.id],n=o.rc+(m?1:0),avg=n?((o.ra||0)*o.rc+(m?m.r:0))/n:0;if(!n||avg<F.minr)continue}
  const s=score(o,q);if(!s)continue;out.push({o,s,b:F.sort==='top'?bayes(o,mine[o.id]):0});
 }
 const by={rel:q?(a,b)=>b.s-a.s||a.o.name.localeCompare(b.o.name):(a,b)=>(a.o.fi||0)-(b.o.fi||0)||a.o.rank-b.o.rank,
  top:(a,b)=>b.b-a.b||b.s-a.s||a.o.name.localeCompare(b.o.name),new:(a,b)=>String(b.o.date).localeCompare(String(a.o.date))||b.s-a.s||a.o.name.localeCompare(b.o.name),
  az:(a,b)=>a.o.name.localeCompare(b.o.name)};
 out.sort(by[F.sort]||by.rel);return out.map(x=>x.o);
}
/* ---------- rendering ---------- */
const hue=s=>hash(s)%360;
function card(o,i){
 const h=hue(o.id),mine=myRatings()[o.id];
 const rating=o.rc?`<span>★ ${o.ra.toFixed(1)} (${o.rc})</span>`:mine?`<span>★ ${mine.r} (you)</span>`:'';
 return `<a class="card sv" href="/s/${esc(o.id)}/" style="animation-delay:${Math.min(i,8)*40}ms"><div class="bn"><div class="bi" style="background:radial-gradient(circle at 82% 18%,hsl(${h+90} 90% 82%/.75),transparent 48%),linear-gradient(135deg,hsl(${h} 78% 70%),hsl(${h+50} 70% 56%))"><small>${esc(o.cat)}</small></div></div><div class="cb"><div class="ic2" style="background:linear-gradient(135deg,hsl(${h} 75% 58%),hsl(${h+40} 70% 42%))">${esc([...o.name][0]||'?')}</div><div class="hd2"><div class="tx"><h3><span>${esc(o.name)}</span>${o.status==='verified'?ico('shield','vf'):''}</h3><div class="st2">${o.lang?`<span>${esc(o.lang)}</span>`:''}${rating}</div></div></div><p class="ds">${esc(o.desc)||'No description provided.'}</p></div></a>`;
}
function emptyHtml(){
 const q=F.q.trim();
 if(!S.recs.length)return ['No servers available','The directory data could not be loaded or is empty. '+(S.errors[0]?esc(S.errors[0]):'Add a data file to /data and list it in manifest.json.'),'retry','Try again'];
 const cats=[...new Set(S.recs.map(r=>r.cat))].slice(0,5).map(c=>`<a href="/c/${slug(c)}/">${esc(c)}</a>`).join(', ');
 return ['No servers found',(q?`Nothing matches “${esc(q)}”. `:'Nothing matches these filters. ')+`Try fewer words, check spelling, or browse a category: ${cats}.`,'reset','Clear search and filters'];
}
function draw(reset){
 const g=$('#grid');if(reset){g.innerHTML='';S.shown=0}
 const end=Math.min(S.res.length,S.shown+PAGE);
 if(end>S.shown)g.insertAdjacentHTML('beforeend',S.res.slice(S.shown,end).map((o,i)=>card(o,i)).join(''));
 S.shown=end;
 if(!S.res.length){const[h,p,a,t]=emptyHtml();g.innerHTML=`<div class="empty"><h2>${h}</h2><p>${p}</p><button class="btn p" data-a="${a}">${t}</button></div>`}
 const more=S.shown<S.res.length||S.next<S.files.length;
 $('#more').textContent=S.res.length&&!more?'You’ve reached the end of the directory.':'';
 $('#rl').innerHTML=S.res.length?`<span>${S.res.length} server${S.res.length>1?'s':''}${F.q.trim()?'':(F.sort==='rel'?' · order rotates daily':'')}${S.next<S.files.length?' · more loading':''}</span><button class="btn t" data-a="random" style="height:44px;padding:0 8px">Random server</button>`:'';
 const n=(F.cat?1:0)+(F.lang?1:0)+(F.region?1:0)+F.ver+(F.minr?1:0)+(F.sort!=='rel'?1:0),fc=$('#fc');fc.hidden=!n;fc.textContent=n;
}
let gen=0;
async function run(){
 const my=++gen,needAll=F.q.trim()||F.cat||F.lang||F.region||F.ver||F.minr||F.sort!=='rel';
 if(needAll)await loadAll();if(my!==gen)return;
 tagFiles();S.res=compute();draw(true);syncUrl();
}
function tagFiles(){S.recs.forEach((o,i)=>{if(o.fi===undefined)o.fi=0})}
async function more(){ // infinite scroll: render next page, or lazily fetch the next data file
 if(S.shown<S.res.length){draw(false);return}
 if(S.next<S.files.length&&!S.loading){const idx=S.recs.length;await loadNext();S.recs.slice(idx).forEach(o=>o.fi=S.next);S.res=compute();draw(false)}
}
function syncUrl(){const p=new URLSearchParams();if(F.q.trim())p.set('q',F.q.trim());if(F.cat)p.set('c',F.cat);if(F.sort!=='rel')p.set('s',F.sort);
 const u=location.pathname+(p.toString()?'?'+p:'');try{history.replaceState(null,'',u)}catch{}}
/* ---------- suggestions + recent searches ---------- */
let sel=-1;
const recent=()=>store.get('harbor6.recent',[]);
function addRecent(q){q=q.trim();if(!q)return;const r=[q,...recent().filter(x=>x.toLowerCase()!==q.toLowerCase())].slice(0,6);store.set('harbor6.recent',r)}
function suggest(){
 const v=norm($('#q').value),box=$('#sgl');let items=[];
 if(!v)items=recent().map(t=>({t,k:'Recent'}));
 else{const seen=new Set();for(const o of S.recs){for(const c of [[o.name,'Server'],...o.tags.map(t=>[t,'Topic']),[o.cat,'Category']]){const n=norm(c[0]);if(n.startsWith(v)||n.split(' ').some(w=>w.startsWith(v))){if(!seen.has(n)){seen.add(n);items.push({t:c[0],k:c[1]})}}}if(items.length>=30)break}
  items.sort((a,b)=>(norm(a.t).startsWith(v)?0:1)-(norm(b.t).startsWith(v)?0:1));items=items.slice(0,6)}
 sel=-1;box.hidden=!items.length;$('#q').setAttribute('aria-expanded',String(!box.hidden));
 box.innerHTML=items.map((x,i)=>`<button type="button" role="option" id="sg${i}" data-a="pick" data-t="${esc(x.t)}">${esc(x.t)}<small>${x.k}</small></button>`).join('')+(!v&&items.length?'<button type="button" data-a="clearrecent"><small style="margin:0">Clear recent searches</small></button>':'');
}
function setQ(t,save){$('#q').value=t;F.q=t;$('#sgl').hidden=true;if(save)addRecent(t);run()}
/* ---------- sheets ---------- */
function openSheet(h){$('#shc').innerHTML=h;$('#sh').classList.add('on');$('#bd').classList.add('on');$('#shc').scrollTop=0;const c=$('#shc [data-a=close]');c&&c.focus()}
function close(){$('#sh').classList.remove('on');$('#bd').classList.remove('on');$('#q').focus({preventScroll:true})}
const swr=(t,sm,a,on)=>`<div class="row"><div class="rt"><b>${t}</b>${sm?`<small>${sm}</small>`:''}</div><button class="sw ${on?'on':''}" role="switch" aria-checked="${!!on}" aria-label="${t}" data-a="${a}"></button></div>`;
const opt=(v,l,cur)=>`<option value="${esc(v)}" ${cur===v?'selected':''}>${esc(l)}</option>`;
function fsheet(){
 const cats=[...new Set(S.recs.map(r=>r.cat))].sort(),langs=[...new Set(S.recs.map(r=>r.lang).filter(Boolean))].sort(),regs=[...new Set(S.recs.map(r=>r.region).filter(Boolean))].sort(),hasVer=S.recs.some(r=>r.status==='verified');
 return `<div class="sht"><button class="btn t" data-a="reset" style="height:44px;padding:0 8px">Reset</button><b id="ft">Filters</b><button class="btn t" data-a="close" style="height:44px;padding:0 8px;font-weight:700">Done</button></div>
<h3 class="gh">Category</h3><div class="grp"><div class="row"><div class="rt"><b>Category</b></div><select class="sel" id="fcat" aria-label="Category">${opt('','All categories',F.cat)}${cats.map(c=>opt(c,c,F.cat)).join('')}</select></div>
${langs.length>1?`<div class="row"><div class="rt"><b>Language</b></div><select class="sel" id="flang" aria-label="Language">${opt('','Any',F.lang)}${langs.map(c=>opt(c,c,F.lang)).join('')}</select></div>`:''}
${regs.length?`<div class="row"><div class="rt"><b>Region</b></div><select class="sel" id="freg" aria-label="Region">${opt('','Any',F.region)}${regs.map(c=>opt(c,c,F.region)).join('')}</select></div>`:''}</div>
<h3 class="gh">Sort</h3><div class="grp"><div class="row"><div class="rt"><b>Sort by</b><small>Trending is not offered: there is no shared activity data to base it on.</small></div><select class="sel" id="fso" aria-label="Sort by">${opt('rel','Best match',F.sort)}${opt('top','Top rated (ratings on this device)',F.sort)}${opt('new','Newest',F.sort)}${opt('az','A to Z',F.sort)}</select></div></div>
<h3 class="gh">Rating</h3><div class="seg" style="margin:8px 0 0">${[[0,'Any'],[3,'3+'],[4,'4+']].map(x=>`<button class="${F.minr==x[0]?'on':''}" data-a="fr" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>
<p class="note" style="font-size:13px;color:var(--t2);margin:8px 4px 0">Ratings are saved on this device only and are not shared with other visitors.</p>
${hasVer?`<div class="grp" style="margin-top:24px">${swr('Verified only','Only invites that were actually checked','fv',F.ver)}</div>`:''}
<div class="grp" style="margin-top:24px"><button class="row" data-a="random"><div class="rt"><b>Random server</b><small>Open a randomly chosen listing</small></div>${ico('compass')}</button></div>`;
}
const refilter=()=>{const s=$('#shc').scrollTop;$('#shc').innerHTML=fsheet();$('#shc').scrollTop=s;run()};
const A={close,
 menu(){loadAll().then(()=>openSheet(fsheet()))},
 fr(b){F.minr=+b.dataset.v;refilter()},fv(){F.ver=F.ver?0:1;refilter()},
 reset(){F.q='';$('#q').value='';Object.assign(F,{cat:'',lang:'',region:'',ver:0,minr:0,sort:'rel'});if($('#sh').classList.contains('on'))$('#shc').innerHTML=fsheet();run()},
 pick(b){setQ(b.dataset.t,true)},clearrecent(){store.set('harbor6.recent',[]);suggest()},
 retry(){S.next=0;S.recs=[];S.ids.clear();S.codes.clear();S.names.clear();S.errors=[];init().then(run)},
 async random(){await loadAll();const pool=compute();const list=pool.length?pool:S.recs;if(!list.length)return;location.href='/s/'+list[Math.floor(Math.random()*list.length)].id+'/'}};
document.addEventListener('click',e=>{const a=e.target.closest('[data-a]');if(a&&A[a.dataset.a]){e.preventDefault();A[a.dataset.a](a)}else if(!e.target.closest('.fs'))$('#sgl').hidden=true});
document.addEventListener('change',e=>{const i=e.target.id;if(i==='fcat'){F.cat=e.target.value;refilter()}else if(i==='flang'){F.lang=e.target.value;refilter()}else if(i==='freg'){F.region=e.target.value;refilter()}else if(i==='fso'){F.sort=e.target.value;refilter()}});
let dt;
$('#q').addEventListener('input',e=>{const v=e.target.value;suggest();clearTimeout(dt);dt=setTimeout(()=>{if(v!==F.q){F.q=v;run()}},250)});
$('#q').addEventListener('focus',suggest);
$('#q').addEventListener('keydown',e=>{const b=$$('#sgl button[role=option]');
 if(e.key==='ArrowDown'||e.key==='ArrowUp'){if(!b.length)return;e.preventDefault();sel=(sel+(e.key==='ArrowDown'?1:-1)+b.length)%b.length;b.forEach((x,i)=>x.setAttribute('aria-selected',i===sel));$('#q').setAttribute('aria-activedescendant',b[sel].id)}
 else if(e.key==='Enter'){e.preventDefault();clearTimeout(dt);if(sel>=0&&b[sel])return setQ(b[sel].dataset.t,true);F.q=e.target.value;$('#sgl').hidden=true;addRecent(F.q);run()}
 else if(e.key==='Escape'){$('#sgl').hidden=true;close()}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('#sh').classList.contains('on'))close()});
new IntersectionObserver(es=>{if(es[0].isIntersecting)more()},{rootMargin:'800px'}).observe($('#more'));
(async()=>{
 const p=new URLSearchParams(location.search);F.q=(p.get('q')||'').slice(0,100);F.cat=p.get('c')||'';if(['top','new','az'].includes(p.get('s')))F.sort=p.get('s');$('#q').value=F.q;
 $('#grid').innerHTML='<div class="sk"></div><div class="sk"></div><div class="sk"></div>';
 await init();S.recs.forEach(o=>o.fi=0);await run();
 window.__harbor={S,F,norm,score,ingest,compute,bayes};            // read-only handle used by the automated tests
})();
})();
